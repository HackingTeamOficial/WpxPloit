<h2 align="center"> WPXploit </h2>


<p align="center"> Simple Python Script For Performing XMLRPC Dictionary Attack </p>


![Build Status](https://travis-ci.com/relarizky/wpxploit.svg?branch=master)
![Code Size](https://img.shields.io/github/languages/code-size/relarizky/wpxploit?color=brightgreen)
![License](https://img.shields.io/github/license/relarizky/wpxploit)


<img src="https://raw.githubusercontent.com/relarizky/wpxploit/master/screenshot/help.png" width=35% height=50%> <img src="https://raw.githubusercontent.com/relarizky/wpxploit/master/screenshot/action.png" width=35% height=50%>


## Instalation
```
$ git clone https://github.com/relarizky/wpxploit.git
$ cd wpxploit
$ pip3 install -r requirements.txt
$ ./exploit.py
```


## Usage
```
__          _________   __      _       _ _
\ \        / /  __ \ \ / /     | |     (_) |
 \ \  /\  / /| |__) \ V / _ __ | | ___  _| |_
  \ \/  \/ / |  ___/ > < | '_ \| |/ _ \| | __|
   \  /\  /  | |    / . \| |_) | | (_) | | |_
    \/  \/   |_|   /_/ \_\ .__/|_|\___/|_|\__|
                         | |   [Version 1.0.0]
                         |_|

[+] Usage	: ./exploit.py <url> <thread> <timeout>
[+] Examlple	: ./exploit.py http://target.com/ 5 15
```
